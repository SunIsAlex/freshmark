// Stand-in for Google's AdSense / H5 Games Ads API (adsbygoogle.js), which
// rules.json blocks. Games on files.twoplayergames.org call adConfig() and
// adBreak() and some wait for the callbacks before starting or resuming, so
// this answers every request the way the real SDK does when no ad is ready.
(() => {
  "use strict";

  const later = (callback, ...args) => {
    if (typeof callback !== "function") return;
    setTimeout(() => {
      try {
        callback(...args);
      } catch (error) {
        console.error(error);
      }
    }, 0);
  };

  const handle = (request) => {
    if (!request || typeof request !== "object") return;
    // adConfig({ onReady }) – the SDK reports it is ready.
    later(request.onReady);
    // adBreak({ type, name, adBreakDone }) – no ad was shown.
    if ("type" in request || "adBreakDone" in request) {
      later(request.adBreakDone, {
        breakType: request.type,
        breakName: request.name,
        breakFormat: request.type === "reward" ? "reward" : "interstitial",
        breakStatus: request.type === "reward" ? "notReady" : "noAdPreloaded",
      });
    }
  };

  const shim = {
    loaded: true,
    push(...requests) {
      requests.forEach(handle);
      return 0;
    },
  };

  // Pages write `adsbygoogle = window.adsbygoogle || []`; keep the shim even
  // if one assigns a fresh array, and replay anything already queued in it.
  Object.defineProperty(window, "adsbygoogle", {
    configurable: true,
    get: () => shim,
    set: (value) => {
      if (Array.isArray(value)) value.forEach(handle);
    },
  });
})();
